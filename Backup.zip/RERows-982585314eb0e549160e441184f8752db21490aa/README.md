REROWS(REthinked bROWSer)[code name] is simple web browser inspired by:
 *  Firefox:
    * Aurialis UI
    * Paronama
    * Addons:
        * BackToTop
        * FlashBlock
        * AddToSearchBar
        * UndoTab
        * AdBlock
        * OpenWith

 * Google Chrome - ominbox
 * Opera 12 Addons

You need python version 2.7 or 3.x and Gtk and Webkit from gi repository.
To run: python rerows.py

"Warning: This program is not finshed"

Features:
* google search in adrees bar
* history back and forward buttons
* fix address mistake
* zoom in & out & and reset to 100%
* go to top
* show favicon
* progress in url bar

